﻿namespace WeatherStation.Controllers
{
    public class AppOptions
    {
    }
}